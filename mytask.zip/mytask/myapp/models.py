from django.db import models

class productadd(models.Model):
   
    name=models.CharField(max_length=15)
    description=models.TextField(max_length=50)
    #price=models.DecimalField(max_digits=15,decimal_places=2) 
    price=models.FloatField()

class adminlogin(models.Model):
   
    email=models.EmailField(max_length=30)
    password=models.CharField(max_length=20)
 
   
