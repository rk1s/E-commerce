from django.urls import path,include
from.import views

urlpatterns = [
    path('',views.home),
    path('login',views.login),
    path('productadd',views.productadd),
    path('addproduct',views.addproduct),
    path('addproductTask',views.addproductTask),
    path('logout',views.logout),
    path('show',views.show),
    path('delete',views.delete),
    path('update',views.update),
    path('updateproduct',views.updateproduct),


]
