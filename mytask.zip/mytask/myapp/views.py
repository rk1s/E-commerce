from django.shortcuts import render,redirect
from .models import adminlogin,productadd
import decimal

def home(req):
      return render(req,"login.html")

def login(req):
     
      email=req.GET.get('email')
      password=req.GET.get('password')
      rec=adminlogin.objects.filter(email=email,password=password)
      return render(req,"admin.html")
        
              


def logout(req):
     return redirect("/")

def addproduct(req):
           return render(req,'add.html')

def addproductTask(req):
        ob=productadd()
        ob.name=req.GET.get('name')
        ob.description=req.GET.get('description')
        #ob.price=decimal.Decimal(req.GET.get('price'))
        ob.price=float(req.GET.get('price'))
        ob.save()
        return redirect('/addproduct')




def show(req):
      rakesh=productadd.objects.all()
      return render(req,'show.html',{'rec':rakesh})
           





def delete(req):
        ob=productadd()
        ob.id=req.GET.get('Pid')
        ob.delete()
        return redirect("/show")
        

def update(req):
         ob=productadd()
         ob.id=req.GET.get('uid')
         rec=productadd.objects.filter(id=ob.id)
         return render(req,"update.html",{'rec':rec})

def updateproduct(req):
          
          ob=productadd()
          ob.id=req.GET.get('upid')
          ob.name=req.GET.get('name')
          ob.description=req.GET.get('description')
          ob.price=float(req.GET.get('price'))
          ob.save()
          
          return redirect('/show')
